Samoerai is free to use, designed for all of your personal and commercial use.
I would appreciate it if you could send me a picture of Samoerai in use in any of your projects!
 
Contact : Jos_schoot_uiterkamp@hotmail.com
